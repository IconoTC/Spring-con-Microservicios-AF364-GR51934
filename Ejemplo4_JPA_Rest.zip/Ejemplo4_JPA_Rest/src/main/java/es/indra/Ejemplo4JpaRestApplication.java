package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.persistence.Alumno;
import es.indra.persistence.AlumnosDAO;

@SpringBootApplication
public class Ejemplo4JpaRestApplication implements CommandLineRunner{
	
	@Autowired
	private AlumnosDAO dao;
		
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("Cuantos registros hay? " + dao.count());
		
		dao.save(new Alumno("Manuel", 10));
		
		System.out.println("----- Todos los alumnos -----");
		dao.findAll().forEach(System.out::println);
		
		// buscar por pk
		System.out.println("----- Buscar alumno ------");
		System.out.println(dao.findById(4).get());
		
		// borrar si existe
		dao.findById(7).ifPresent(encontrado -> dao.delete(encontrado));
		
		System.out.println("----- Todos los alumnos -----");
		dao.findAll().forEach(System.out::println);
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4JpaRestApplication.class, args);
	}

}
