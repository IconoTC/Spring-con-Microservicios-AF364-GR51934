package es.indra.services;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GradosRest {
	
	// http://localhost:8080/fahrenheit/37
	@RequestMapping("/fahrenheit/{grados}")
	public double gradosAFahrenheit(@PathVariable  double grados) {
		return (grados * 9/5) + 32;
	}
	
	// http://localhost:8080/grados/98.6
	@RequestMapping("/grados/{fahrenheit}")
	public double fahrenheitAGrados(@PathVariable  double fahrenheit) {
		return (fahrenheit - 32) * 5/9;
	}

}


// ctrl + shift + o     importar