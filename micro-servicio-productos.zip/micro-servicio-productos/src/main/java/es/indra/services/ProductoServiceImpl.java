package es.indra.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.models.entity.Producto;
import es.indra.persistence.ProductosDAO;

@Service
public class ProductoServiceImpl implements IProductoService{
	
	@Autowired
	private ProductosDAO dao;

	@Override
	public List<Producto> consultarTodos() {
		return (List<Producto>) dao.findAll();
	}

	@Override
	public Producto buscarProducto(Long id) {
		return dao.findById(id).orElse(new Producto());
	}

}
