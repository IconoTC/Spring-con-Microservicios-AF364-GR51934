package es.indra;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.indra.persistence.Alumno;
import es.indra.persistence.AlumnosDAO;

@SpringBootApplication
public class Ejemplo6TransaccionesApplication implements CommandLineRunner{
	
	@Autowired
	private AlumnosDAO dao;
		
	
	@Override
	public void run(String... args) throws Exception {
		List<Alumno> lista = new ArrayList<Alumno>();
		lista.add(new Alumno(1, "Juan", 7.2));
		lista.add(new Alumno(2, "Maria", 3.5));
		lista.add(new Alumno(3, "Pedro", 6.3));
		
		// No genera error, si la PK ya existe, en JPA se entiende con update
		lista.add(new Alumno(2, "Maria", 5));
		
		// Si creo un alumno vacio, que no tiene PK, eso SI da ERROR
		lista.add(new Alumno());
		
		try {
			insertar(lista);
		} catch (Exception e) {
			System.out.println("Ha ocurrido un error");
		}
		
		// Mostrar todos los alumnos
		dao.findAll().forEach(System.out::println);
	}
	
	@Transactional(propagation = Propagation.REQUIRED,
			isolation = Isolation.SERIALIZABLE,
			rollbackFor = Exception.class)
	public void insertar(List<Alumno> lista) {
		
		// El metodo save gestiona cada transaccion de forma independiente 
		// dao.save(alumno);
		
		// El metodo saveAll se gestiona como una transaccion unica
		dao.saveAll(lista);
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo6TransaccionesApplication.class, args);
	}

}
