package es.indra.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import es.indra.models.Item;

@FeignClient(name = "servicio-items")
public interface ItemClientRest {
	
	@GetMapping("/ver/{id}/cantidad/{cantidad}")
	public Item crearItem(@PathVariable Long id, @PathVariable Integer cantidad);

}
