package es.indra.persistence;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "ALUMNOS", path = "alumnos")
public interface AlumnosDAO extends MongoRepository<Alumno, String>{
	
	// Mostrar todos los alumnos
	// http://localhost:8080/alumnos
	
	// Buscar un alumno por su id
	// http://localhost:8080/alumnos/2
	
	// Utilizamos los metodos heredados de CrudRepository
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/
	
	// Podemos crear nuestros propios metodos utilizando palabras clave
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords
	
	// http://localhost:8080/alumnos/search/findByNombre?nombre=Maria
	public List<Alumno> findByNombre(String nombre);
	
	
	// Mostrar todos los alumnos ordenados por nota ascendente
	// http://localhost:8080/alumnos/search/OrderByNota
	public List<Alumno> OrderByNota();
	
	// Mostrar todos los alumnos ordenados por nota descendente
	// http://localhost:8080/alumnos/search/OrderByNotaDesc
	public List<Alumno> OrderByNotaDesc();
	
	
	// Buscar por nota ordenados por nombre descendente
	// http://localhost:8080/alumnos/search/findByNotaOrderByNombreDesc?nota=7.2
	public List<Alumno> findByNotaOrderByNombreDesc(double nota);
	
	
	// Buscar los alumnos con nota entre 5 y 10  (between)
	// http://localhost:8080/alumnos/search/findByNotaBetween?min=5&max=10
	public List<Alumno> findByNotaBetween(double min, double max);
	
	
	// Todos los metodos implementados se pueden ver en esta url
	// http://localhost:8080/alumnos/search
}
