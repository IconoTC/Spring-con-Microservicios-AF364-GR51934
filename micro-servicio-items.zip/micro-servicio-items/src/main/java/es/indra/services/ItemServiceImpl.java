package es.indra.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import es.indra.models.Item;
import es.indra.models.Producto;

@Service
public class ItemServiceImpl implements ItemService{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Item buscarItem(Long id, Integer cantidad) {
		Producto producto = restTemplate.getForObject(
				"http://localhost:8001/buscar/{id}", Producto.class, id);
		return new Item(producto, cantidad);
	}
	

}
