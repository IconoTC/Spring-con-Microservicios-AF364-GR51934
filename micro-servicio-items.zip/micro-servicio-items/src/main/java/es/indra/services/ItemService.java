package es.indra.services;

import es.indra.models.Item;

public interface ItemService {
	
	Item buscarItem(Long id, Integer cantidad);
	

}
