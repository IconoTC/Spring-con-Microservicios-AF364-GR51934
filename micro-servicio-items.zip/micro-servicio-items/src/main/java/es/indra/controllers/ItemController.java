package es.indra.controllers;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Item;
import es.indra.services.ItemService;

@RestController
public class ItemController {
	
	// La anotacion @Autowired no me permite poner el id del bean a inyectar
//	@Autowired
//	@Qualifier("serviceFeign")
	
	// @Resource si que lo permite
	@Resource(name = "serviceFeign")
	private ItemService itemService;
	
	// http://localhost:8002/ver/4/cantidad/10
	@GetMapping("/ver/{id}/cantidad/{cantidad}")
	public Item crearItem(@PathVariable Long id, @PathVariable Integer cantidad) {
		return itemService.buscarItem(id, cantidad);
	}

}
