package es.indra.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.entity.Producto;
import es.indra.services.IProductoService;

@RestController
public class ProductoController {
	
	@Autowired
	private IProductoService productoService;
	
	// OJO!!!  con puerto dinamico no funciona esta opcion
//	@Value("${server.port}")
//	private Integer port;
	
	
	// Otra forma de obtener el puerto
	@Autowired
	private HttpServletRequest request;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return productoService.consultarTodos();
	}
	
	// http://localhost:8001/buscar/2
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id) {
		Producto producto = productoService.buscarProducto(id);
		//producto.setPort(port);
		producto.setPort(request.getLocalPort());
		return producto;
	}

}
