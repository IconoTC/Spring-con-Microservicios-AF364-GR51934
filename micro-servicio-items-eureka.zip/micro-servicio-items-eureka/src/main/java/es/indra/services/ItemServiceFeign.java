package es.indra.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.clients.ProductoClienteRest;
import es.indra.models.Item;

@Service("serviceFeign")
//@Primary    // Marca este bean como preferido para DI
public class ItemServiceFeign implements ItemService{
	
	@Autowired
	private ProductoClienteRest clienteFeign;

	@Override
	public Item buscarItem(Long id, Integer cantidad) {
		return new Item(clienteFeign.buscar(id), cantidad);
	}
	


}
