package es.indra.controllers;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import es.indra.models.Item;
import es.indra.models.Producto;
import es.indra.services.ItemService;

@RestController
public class ItemController {
	
	// La anotacion @Autowired no me permite poner el id del bean a inyectar
//	@Autowired
//	@Qualifier("serviceFeign")
	
	// @Resource si que lo permite
	@Resource(name = "serviceFeign")
	//@Resource(name = "serviceRestTemplate")
	private ItemService itemService;
	
	// http://localhost:8002/ver/4/cantidad/10
	@GetMapping("/ver/{id}/cantidad/{cantidad}")
	// En el caso de recibir una excepcion llamamos al metodo manejarError
	@HystrixCommand(fallbackMethod = "manejarError")
	public Item crearItem(@PathVariable Long id, @PathVariable Integer cantidad) {
		return itemService.buscarItem(id, cantidad);
	}
	
	
	public Item manejarError(Long id, Integer cantidad, Throwable ex) {
		// com.netflix.hystrix.exception.HystrixTimeoutException
		System.out.println(ex.getClass() + "**************");
		System.out.println(ex.getMessage() + "-----------------------------");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		return new Item(producto, cantidad);
	}

}
